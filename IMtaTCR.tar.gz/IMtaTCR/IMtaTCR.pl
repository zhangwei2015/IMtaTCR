#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Basename;
use FindBin qw($Bin $Script);


=head1  Usage
	perl IMtaTCR.pl -i -o -R [parameters]

=head1 Description
	IMtaTCR: to identify tumor-associated TCRs (taTCRs) by comparing the TCR repertoire in tumors with that in normal tissue

=head1 [parameters]

        -i      <S> input file
        -o      <S> out directory
        -R      <S> directory of Rscript [usr/bin/Rscript]

        -n     <I>  total read number for individual's normalization [100000]
	-f1     <Fl> select cluster with the frequency TCRs in tumor for GLIPH2 and iSMART [0.001]
	-f2     <Fl> select cluster with the frequency TCRs in tumor for ALICE [0.0001]
	-l1	<I> select cluster with foldchange from DEGseq for GLIPH2 and iSMART [2]
	-l2     <I> select cluster with ratio(tumor/normal) for ALICE [2]
	-p1	<Fl> select cluster with p-value from DEGseq for GLIPH2 and iSMART [1e-10]

=head1 Note

        1. If the sequence including C region, the compulsory parameters: -i -o R

=cut

my ($input_f, $Rscript, $cutoff_f_1, $cutoff_f_2, $cutoff_l_1, $cutoff_l_2, $cutoff_p_1, $normalize_n, $out);
GetOptions(
                "i=s" => \$input_f,
                "o=s" => \$out,
		"R:s" => \$Rscript,
		"n:i" => \$normalize_n,
		"f1:f" => \$cutoff_f_1,
		"f2:f" => \$cutoff_f_2,
		"l1:i" => \$cutoff_l_1,
		"l2:i" => \$cutoff_l_2,
		"p1:f" => \$cutoff_p_1,
          );


die `pod2text $0` if (!$input_f or !$out or !$Rscript);


$normalize_n = 100000 unless(defined($normalize_n));
$cutoff_f_1 = 0.001 unless(defined($cutoff_f_1));
$cutoff_f_2 = 0.0001 unless(defined($cutoff_f_2));
$cutoff_l_1 = 2 unless(defined($cutoff_l_1));
$cutoff_l_2 = 2 unless(defined($cutoff_l_2));
$cutoff_p_1 = 1e-10 unless(defined($cutoff_p_1));

$cutoff_f_1 = $normalize_n*$cutoff_f_1;
$cutoff_f_2 = $normalize_n*$cutoff_f_2;

$Rscript = "usr/bin/Rscript" unless(defined($Rscript));
#$top_clone_n = 5000 unless(defined($top_clone_n));

#----- change to absolute path
my $current_path=$ENV{"PWD"};
#$id_f_list = "$current_path/$id_f_list" unless($id_f_list=~/^\//);
#$ic_f_list = "$current_path/$ic_f_list" unless($ic_f_list=~/^\//);
$out = "$current_path/$out" unless($out=~/^\//);
$input_f = "$current_path/$input_f" unless($input_f =~ /^\//);


system "mkdir -p $out/Input" unless(-d "$out/Input");
system "mkdir -p $out/Input/Tumor" unless(-d "$out/Input/Tumor");
system "mkdir -p $out/Input/Normal" unless(-d "$out/Input/Normal");
system "mkdir -p $out/Input/Patient" unless(-d "$out/Input/Patient");
system "mkdir -p $out/ALICE" unless(-d "$out/ALICE");
system "mkdir -p $out/iSMART" unless(-d "$out/iSMART");
system "mkdir -p $out/GLIPH2" unless(-d "$out/GLIPH2");


#   1. Identify Disease specific clones   -------------
open O, ">$out/step1.sh" or die;

#print O "mkdir $out/Input $out/Input/Tumor $out/Input/Normal $out/Input/Patient $out/ALICE $out/iSMART $out/GLIPH2\n";
print O "perl $Bin/Gene_format_input.pl $input_f $out/Input >$out/Patient_samples.txt\n";
print O "perl $Bin/Com_patient.pl $out/Patient_samples.txt $out/Input/Normal $out/Input/Tumor $normalize_n $out/Input/Patient\n";
print O "ls $out/Input/Patient/*.gliph2.input >$out/GLIPH2/input.list\n";
print O "perl $Bin/Create_par_GLIPH2.pl $out/GLIPH2/input.list $Bin/gliph2 $out/GLIPH2\n";
print O "ls $out/GLIPH2/*.par|awk \'{print \"$Bin/gliph2/irtools.centos -c \"\$1;}' >$out/GLIPH2/step2_gliph2.sh\n";
print O "perl $Bin/Create_sh_GLIPH2.V2.pl $out/Patient_samples.txt $out/Input/Tumor $out/Input/Normal $out/GLIPH2 $normalize_n $cutoff_f_1 $cutoff_l_1 $cutoff_p_1 $Bin $Rscript >$out/step3.sh\n";

if(-d "$out/iSMART/input"){
	unlink glob "$out/iSMART/input/*";
}else{
	system "mkdir -p $out/iSMART/input";
}
print O "ls $out/Input/Patient/*.iSMART.input|awk -F\"/\" \'{print \"ln -s \"\$0\" $out/iSMART/input/\"\$NF\".tsv\";}\' |sh -\n";
print O "echo \"python3 $Bin/iSMART/iSMARTm.py -d $out/iSMART/input -o $out/iSMART\" >$out/iSMART/step2_ismart.sh\n";
print O "perl $Bin/Create_sh_iSMART.V2.pl $out/Patient_samples.txt $out/Input/Tumor $out/Input/Normal $out/iSMART $normalize_n $cutoff_f_1 $cutoff_l_1 $cutoff_p_1 $Bin $Rscript >>$out/step3.sh\n";

print O "ls $out/Input/Patient/*.alice.input |awk -F\"[/.]\" \'{print \"$Rscript $Bin/ALICE-master/Pipeline.R \"\$0\" $out/ALICE/\"\$(NF-2)\" \"\$(NF-2)\".alice\"}\' >$out/ALICE/step2_alice.sh\n";
print O "perl $Bin/Create_sh_Alice.V2.pl $out/Patient_samples.txt $out/Input/Tumor $out/Input/Normal $out/ALICE $normalize_n $cutoff_l_2 $cutoff_f_2 $Bin >>$out/step3.sh\n";

print O "echo \"ls GLIPH2/*.selected.final |perl $Bin/Combined_tumor_specific_clones.V3.pl - >$out/taTCR.selected.all\" >>$out/step3.sh\n";
close O;




