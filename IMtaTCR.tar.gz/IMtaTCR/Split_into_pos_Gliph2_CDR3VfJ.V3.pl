#!/usr/bin/perl -w
use strict;

die "perl $0 <gliph2><tumor><normal><blood><norm_num>\n" unless(@ARGV==5);


my ($in_f,$tumor_f,$normal_f,$blood_f, $norm_num) = @ARGV;

my %All;
my %tot_n_a;

if($tumor_f ne "NA"){
open I, "$tumor_f" or die;
<I>;
while(<I>)
{
	chomp;
	my @line = split;
	my $cdr3 = $line[0];
	my $clone = "$line[0]_$line[1]_$line[2]";
	push @{$All{$cdr3}{$clone}}, "Tumor:$line[5]";
	$tot_n_a{"Tumor"} += $line[5];
}
close I;
}

if($normal_f ne "NA")
{
open I, "$normal_f" or die;
<I>;
while(<I>)
{
        chomp;
        my @line = split;
	#my ($nt,$cdr3,$v,$j) = split /_/,$line[0];
	#push @{$All{$cdr3}{$line[0]}}, "Normal:$line[2]";
	my $cdr3 = $line[0];
        my $clone = "$line[0]_$line[1]_$line[2]";
        push @{$All{$cdr3}{$clone}}, "Normal:$line[5]";
	$tot_n_a{"Normal"} += $line[5];
}
close I;
}

if($blood_f ne "NA")
{
open I, "$blood_f" or die;
<I>;
while(<I>)
{
        chomp;
        my @line = split;
	#my ($nt,$cdr3,$v,$j) = split /_/,$line[0];
	#push @{$All{$cdr3}{$line[0]}}, "Blood:$line[2]";
	my $cdr3 = $line[0];
        my $clone = "$line[0]_$line[1]_$line[2]";
        push @{$All{$cdr3}{$clone}}, "Blood:$line[5]";
	$tot_n_a{"Blood"} += $line[5];
}
close I;
}

open I, "$in_f" or die;
print "id\ttot_num\ttot_freq\ttumor\ttumor_num\tfreq1\tnormal\tnormal_num\tfreq2\tblood\tblood_num\tfreq3\n";

while(<I>)
{
	chomp;
	my @line = split;
	next if($line[0] >0.05 || $line[3] eq "single");
	my %pos;
	my $tot_freq = 0;
	for(my $i=4;$i<=$#line;$i++)
	{
		if(exists $All{$line[$i]})
		{
			for my $clone (keys %{$All{$line[$i]}})
			{
			for(@{$All{$line[$i]}{$clone}})
			{
				my ($p,$f) = split /:/,$_;
				$pos{$p}->[0]++;
				$pos{$p}->[1] += $f;
				my $f_new = $f/$tot_n_a{$p}*$norm_num;
				if(defined($pos{$p}->[2])){
					$pos{$p}->[2] .= ":$clone,$f_new";
				}else{
					$pos{$p}->[2] = "$clone,$f_new";
				}
				$tot_freq += $f;
			}
			}
		}	
	}
	print "$line[3]\t$line[2]\t$tot_freq";
	for("Tumor","Normal","Blood")
	{
		if(($_ eq "Tumor" && $tumor_f eq "NA") || ($_ eq "Normal" && $normal_f eq "NA") || ($_ eq "Blood" && $blood_f eq "NA"))# no sample
		{
			print "\t-\t-\t-";
			next;
		}
		
		if(exists $pos{$_}){
			print "\t$pos{$_}->[2]\t$pos{$_}->[0]\t",int($pos{$_}->[1]/$tot_n_a{$_}*$norm_num);
		}else{
			print "\tna\t0\t0";# no clone
		}
	}
	print "\n";
	
}
close I;
