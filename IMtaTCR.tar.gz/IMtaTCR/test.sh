perl IMtaTCR.pl -i Test/input.txt -o Test/out -R /data/users/zhangwei/R-4.1.0/bin/Rscript
