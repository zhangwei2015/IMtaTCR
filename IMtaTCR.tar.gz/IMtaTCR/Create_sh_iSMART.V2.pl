#!/user/bin/perl -w
use strict;

die "perl $0 <Patient.infor><tumor.dir><normal.dir><outdir><norm_num><cluster:tumor_uniq_TCRs><fold_change><pvalue><Bin_dir><Rscript>\n" unless(@ARGV==10);

my ($patient_infor, $tumor_dir, $normal_dir, $outdir,$norm_num,$cutoff_tumor_n,$cutoff_foldchange,$cutoff_pvalue, $Bin, $Rscript) = @ARGV;
#my $Bin = "/data/users/zhangwei/Lung_cancer/Bin";
open I, "$patient_infor" or die;
<I>;
while(<I>)
{
	chomp;
	my @line = split;
	my $ind = "S$line[0]";
	my $tumor;# = "/data/users/zhangwei/Lung_cancer/SCLC/PMID_34789716/Clonotypes/$line[1]/$line[1]_CDR3_AA_Vfamily_Jgene.gz";
	#my $normal = "/data/users/zhangwei/Lung_cancer/SCLC/PMID_34789716/Clonotypes/$line[1]_CDR3_AA_Vfamily_Jgene.gz";
	my $normal = "$normal_dir/$line[1].iSMART.input";
	$normal = "NA" if($line[1] eq "-");
	my $blood = "NA";

	for(my $i=2;$i<=$#line;$i++){
		#$tumor = "/data/users/zhangwei/Lung_cancer/SCLC/PMID_34789716/Clonotypes/$line[$i]_CDR3_AA_Vfamily_Jgene.gz";
		$tumor = "$tumor_dir/$line[$i].iSMART.input";
		$tumor = "NA" if($line[$i] eq "-");
		#print "perl $Bin/Split_into_pos_Gliph2_CDR3VfJ.V2.pl ${ind}_cluster.txt $tumor $normal $blood > $outdir/$ind.$i.split\n";
		print "perl $Bin/Split_into_pos_iSMART_CDR3VfJ.V3.pl $outdir/${ind}.iSMART.input.tsv_ClusteredCDR3s_7.5.txt $tumor $normal $blood $norm_num > $outdir/$ind.$i.split\n";
		print "$Rscript $Bin/DEGseq.R $outdir/$ind.$i.split $outdir/$ind.$i\n";
		print "perl $Bin/Select_tumor_clusters.pl $outdir/$ind.$i.split  $outdir/$ind.$i/output_score.txt $cutoff_tumor_n $cutoff_foldchange $cutoff_pvalue > $outdir/$ind.$i.selected\n";
		print "perl $Bin/Filter_clone.pl $outdir/$ind.$i.selected >$outdir/$ind.$i.selected.final\n";
	}

	#my $blood = "/data/users/zhangwei/Stomach_cancer/Final/Blood_Tumor/$line[3]/$line[3]_CDR3_AA.frequency.clones.gz";
	#my $blood = "NA";
	#$tumor = "NA" if($line[1] eq "-");
	#$normal = "NA" if($line[1] eq "-");
	#$blood = "NA" if($line[3] eq "-");

	#print "perl Split_into_pos_Gliph2_CDR3VfJ.pl ${ind}_cluster.txt $tumor $normal $blood > $ind.split\n";
	#print "perl Select_tumor_clusters_Gliph2.pl $ind.split > $ind.selected\n";
}
close I;
