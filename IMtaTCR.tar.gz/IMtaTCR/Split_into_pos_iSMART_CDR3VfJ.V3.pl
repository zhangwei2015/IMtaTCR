#!/usr/bin/perl -w
use strict;

die "perl $0 <iSMART><tumor><normal><blood><norm_num>\n" unless(@ARGV==5);

my ($in_f,$tumor_f,$normal_f,$blood_f, $norm_num) = @ARGV;

my %All;
if($tumor_f ne "NA"){
open I, "$tumor_f" or die;
while(<I>)
{
	chomp;
	my @line = split;
	push @{$All{"$line[0]_$line[1]_$line[3]"}}, "Tumor:$line[2]";
}
close I;
}

if($normal_f ne "NA")
{
open I, "$normal_f" or die;
while(<I>)
{
        chomp;
        my @line = split;
        push @{$All{"$line[0]_$line[1]_$line[3]"}}, "Normal:$line[2]";
}
close I;
}

if($blood_f ne "NA")
{
open I, "$blood_f" or die;
while(<I>)
{
        chomp;
        my @line = split;
        push @{$All{"$line[0]_$line[1]_$line[3]"}}, "Blood:$line[2]";
}
close I;
}

open I, "$in_f" or die;
print "id\ttot_num\ttot_freq\ttumor\ttumor_num\tfreq1\tnormal\tnormal_num\tfreq2\tblood\tblood_num\tfreq3\n";
<I>;
my %pos;
my %tot_freq;
while(<I>)
{
	chomp;
	my @line = split;
	$tot_freq{$line[4]}->[0]++;
	if(exists $All{"$line[0]_$line[1]_$line[3]"})
	{
		for(@{$All{"$line[0]_$line[1]_$line[3]"}})
		{
			my ($p,$f) = split /:/,$_;
			$pos{$line[4]}{$p}->[0]++;
			$pos{$line[4]}{$p}->[1] += $f;
			my $f_new = $f/100*$norm_num;
			if(defined($pos{$line[4]}{$p}->[2])){
				$pos{$line[4]}{$p}->[2] .= ":$line[0]_$line[1]_$line[3],$f_new";
			}else{
				$pos{$line[4]}{$p}->[2] = "$line[0]_$line[1]_$line[3],$f_new";
			}
			$tot_freq{$line[4]}->[1] += $f;
		}
	}
}
close I;

for my $c (keys %tot_freq)
{
	$tot_freq{$c}->[1] = 0 if(!defined($tot_freq{$c}->[1]));
	print "$c\t$tot_freq{$c}->[0]\t$tot_freq{$c}->[1]";
	for("Tumor","Normal","Blood")
	{
		if(($_ eq "Tumor" && $tumor_f eq "NA") || ($_ eq "Normal" && $normal_f eq "NA") || ($_ eq "Blood" && $blood_f eq "NA"))# no sample
		{
			print "\t-\t-\t-";
			next;
		}
		
		if(exists $pos{$c}{$_}){
			print "\t$pos{$c}{$_}->[2]\t$pos{$c}{$_}->[0]\t",int($pos{$c}{$_}->[1]/100*$norm_num);
		}else{
			print "\tna\t0\t0";# no clone
		}
	}
	print "\n";
}	
