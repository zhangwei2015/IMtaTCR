#!/usr/bin/perl -w
use strict;

die "perl $0 <>\n" unless(@ARGV==1);
open I, "$ARGV[0]" or die;

my %com;
my %samples;
while(<I>)
{
	chomp;
	my @line = split /\//,$_;

	#	open F, "HighFreq_clones/S$line[0].highfreq.clones" or die;
	#while(<F>)
	#{
	#	chomp;
	#	$com{$_}{"HighFreq"} = 1;
	#}
	#close F;

	open F, "GLIPH2/$line[1]" or die;
	while(<F>)
	{
		chomp;
		my @L = split;
		my @A = split /:/,$L[1];
		for(@A){
			next if(/OR/);
			my ($t1,$t2) = split /,/,$_;
			my @N = split /_/,$t1;
			if($N[0] =~ /^C/ && $N[0] =~ /F$/)
			{
			#$N[1] = (split /-/,$N[1])[0];
				$com{"$N[0]_$N[1]_$N[2]"}{"GLIPH2"} = 1;
				$samples{"$N[0]_$N[1]_$N[2]"}{$line[1]} = 1;
			}
		}
	}
	close F;

	open F, "iSMART/$line[1]" or die;
	while(<F>)
	{
		chomp;
		my @L = split;
		my @A = split /:/,$L[1];
		for(@A){
			#			my $cdr3 = (split /_/,$_)[0];
			next if(/OR/);
			my ($t1,$t2) = split /,/,$_;
			my @N = split /_/,$t1;
			#$N[1] = (split /-/,$N[1])[0];
			if($N[0] =~ /^C/ && $N[0] =~ /F$/){
				$com{"$N[0]_$N[1]_$N[2]"}{"iSMART"} = 1;
				$samples{"$N[0]_$N[1]_$N[2]"}{$line[1]} = 1;
			}
		}
	}
	close F;

	open F, "ALICE/$line[1]" or die;
	while(<F>)
	{
		chomp;
		my @L = split;
		next if($L[1] =~ /OR/);
		my @N = split /_/,$L[1];
		if($N[0] =~ /^C/ && $N[0] =~ /F$/)
		{
		#shift @N;
		#$N[1] = (split /-/,$N[1])[0];
			my $new = "$N[0]_$N[1]_$N[2]";
		#		my $cdr3 = (split /_/,$L[1])[1];
			$com{$new}{"ALICE"} = 1;
			$samples{"$N[0]_$N[1]_$N[2]"}{$line[1]} = 1;
		}
	}
	close F;
}
close I;

#open F, "Public_clones/Public_clone.all.1" or die;
#while(<F>)
#{
#	chomp;
#	$com{$_}{"Public"} = 1;
#}
#close F;


for(keys %com)
{
	my $num = scalar(keys %{$com{$_}});
	my $new = join ":",keys %{$com{$_}};
	my $N = scalar(keys %{$samples{$_}});
	print "$_\t$num\t",$new,"\t$N\n";
}

