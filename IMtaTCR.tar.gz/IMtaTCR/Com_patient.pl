#!/usr/bin/perl -w
use strict;

die "perl $0 <patient.infor><Normal.dir.input><Tumor.dir.input><norm.num><outdir>\n" unless(@ARGV==5);

my $outdir = $ARGV[4];

my $norm = $ARGV[3];

open I, "$ARGV[0]" or die;
<I>;
my @dir = ($ARGV[1],$ARGV[2]);
while(<I>)
{
	chomp;
	my @line = split;
	my %ismart;
	my %gliph2;
	my %gliph2_tot;
	my %alice;
	my $flag = 0;

	for(my $i=1;$i<=$#line;$i++)
	{
		next if($line[$i] eq "-");
		$flag++;
		my $Dir = $dir[0];
		if($i>1){
			$Dir = $dir[1];
		}

		open F, "$Dir/$line[$i].iSMART.input" or die;
		<F>;
		while(<F>)
		{
			chomp;
			my @L = split;
			$ismart{"$L[0]\t$L[1]\t$L[3]"} += $L[2];
		}
		close F;
		
		open F, "$Dir/$line[$i].gliph2.input" or die;
		<F>;
		while(<F>)
		{
			chomp;
			my @L = split;
			$gliph2{"$L[0]\t$L[1]\t$L[2]\t$L[3]\t$L[4]"}{$i} = $L[5];
			$gliph2_tot{$i} += $L[5];
		}
		close F;
		open F, "$Dir/$line[$i].alice.input" or die;
		<F>;
		while(<F>)
		{
			chomp;
			my @L = split;
			$alice{"$L[3]\t$L[4]\t$L[5]\t$L[6]"} += $L[2];	
		}
		close F;
	}

	# output
	open O, ">$outdir/S$line[0].iSMART.input" or die;
	print O "aminoAcid\tvMaxResolved\tfrequencyCount\tjMaxResolved\n";
	for(sort {$ismart{$b} <=> $ismart{$a}} keys %ismart)
	{
		my @N = split /\t/,$_;
		print O "$N[0]\t$N[1]\t",$ismart{$_}/$flag,"\t$N[2]\n";
	}
	close O;
	
	my %new;
	open O, ">$outdir/S$line[0].gliph2.input" or die;
	print O "#CDR3b\tTRBV\tTRBJ\tCDR3a\tsubject:condition\tcount\n";
	for my $f(keys %gliph2)
	{
		for(keys %{$gliph2{$f}})
		{
			my $new_num = $gliph2{$f}{$_}/$gliph2_tot{$_}*$norm;
			$new{$f} += $new_num;
		}
	}
	for(sort {$new{$b}<=>$new{$a}} keys %new)
	{
		print O "$_\t",$new{$_}/$flag,"\n";
	}
	close O;

	open O, ">$outdir/S$line[0].alice.input" or die;
	print O "Rank\tRead.count\tRead.proportion\tCDR3.nucleotide.sequence\tCDR3.amino.acid.sequence\tbestVGene\tbestJGene\n";
	my $rank = 0;
	for(sort {$alice{$b} <=> $alice{$a}} keys %alice)
	{
		$rank++;
		my $rate = $alice{$_}/$flag;
		my $num = $norm*$rate/100;
		print O "$rank\t$num\t$rate\t$_\n";
	}
	close O;
}

close I;
