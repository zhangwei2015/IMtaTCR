./irtools.centos -c par
