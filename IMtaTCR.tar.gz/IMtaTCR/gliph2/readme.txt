#Readme
Executable irtools.osx is for MacOs X and irtools.centos is for Linux Centos

Once downloading the tools, type chmod a+x irtools.osx or chmod a+x irtools.centos to change permission of this tools to execute the tool, Type ./irtools.osx or ./irtools.centos, you get this

Program: irtools (Tools for analyzing CDR3 sequence data)
Version: 0.01
Usage:   irtools -c parameter_file
A typical parameter_file looks like the following
#this line will be ignored
out_prefix=Prefix #entry after this pound sign will be ignored
cdr3_file=cdr3_file.txt
hla_file =hla_file.txt
refer_file=ref_file.txt
v_usage_freq_file=ref_V.txt
cdr3_length_freq_file=ref_L.txt
local_min_pvalue=0.001
p_depth = 1000
global_convergence_cutoff = 1
simulation_depth=1000
kmer_min_depth=3
local_min_OVE=10
algorithm=GLIPH2
all_aa_interchangeable=1

Input TCR data are formated as follow
#CDR3b  TRBV  TRBJ  CDR3a  subject:condition count
CSARDQGGAGNQPQHF	TRBV20-1	TRBJ1-5	CAVGVGYKLSF	01/0906:MtbLys	1

All fields are tab-delimited except that subject and condition are delimited with ":". Condition can be anything such as tissue type, cell subset or treatment et al. CDR3b, TRBV, subject, and count are required. Other fields can be replaced with "NA". A demo input TCR dataset can be found at the link TCR

Input HLA data are formated as follow
#subject allele1 allele2
09/0217	DPA1*01:03	DPA1*02:02	DPB1*04:01	DPB1*14:01	DQA1*01:02	DQA1*01:03	DQB1*06:04	DQB1*06:02	DRB1*13:02	DRB1*13:01	DRB3*03:01	DRB3*02:02

All fields are tab-delimited.

Result clusters are formated as follow
#index,pattern,Fisher_score,number_subject, number_unique_cdr3, final_score,hla_score,vb_score,expansion_score,length_score,cluster_size_score,type,ulTcRb,TcRb,V,J,TcRa,Sample,Freq,HLA-A,HLA-B,HLA-C,HLA-DPA1,HLA-DPB1,HLA-DQA1,HLA-DQB1,HLA-DRB1,HLA-DRB3,HLA-DRB4,HLA-DRB5
1,SVAL,4.4e-19,10,16,5.7e-13,4.0e-04,1.0e-03,4.5e-01,3.7e-02,8.6e-05,motif-SVAL,CASSVaLASGANVLTF,CASSVALASGANVLTF,TRBV9,TRBJ2-6,CAGAGGGGFKTIF,02/0152:Meg