#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Basename;
use FindBin qw($Bin $Script);


=head1  Usage

=head1 [parameters]

	Identifing the disease associated clones, classifing two groups using these clones, and evaluating it performance by cross-validation from two group's (control && case) immune repertoire data.

        -id      <S> input clone files of disease samples' list
	-ic      <S> input clone files of control samples' list
        -o      <S> out directory

                
        -cd     <I> cutoff of Disease clone's supporting samples for FDR correction [2]
	-cc	<I> cutoff of Control clone's supporting samples for FDR correction [2]
	-ps	<S> pvalues for classification [1e-20:1e-15:1e-14:1e-13:1e-12:1e-11:1e-10:1e-9:1e-8:1e-7:1e-6:1e-5:1e-4:5e-4:1e-3:5e-3:1e-2:5e-2:1e-1:5e-1:1] 
	-m	<I> mulitple shell for crossvidation, -m means how many smaples would be put together in a shell [10]
	-mode	<S> classification mode. RandomForest or Logistics [RandomForest]
	-topn	<I> use top N clone for final classification [3000]

	-R	<S> directory of Rscript [/hwfssz1/ST_HEALTH/Immune_And_Health_Lab/Public_Software/R/R-3.4.1/bin/Rscript]

=head1 Note

        1. If the sequence including C region, the compulsory parameters: -i -o -n -p

=cut

my ($id_f_list, $ic_f_list, $Rscript, $cutoff_d_fdr, $cutoff_c_fdr,$pvalues_in,$out, $multiple, $mode, $top_clone_n);
GetOptions(
                "id=s" => \$id_f_list,
                "ic=s" => \$ic_f_list,
                "o=s" => \$out,
		"R:s" => \$Rscript,
		"cd:i" => \$cutoff_d_fdr,
		"cc:i" => \$cutoff_c_fdr,
		"ps:s" => \$pvalues_in,
		"m:i" => \$multiple,
		"mode:s" =>\$mode,
		"topn:i" => \$top_clone_n
          );


die `pod2text $0` if (!$id_f_list or !$out  or !$ic_f_list);


$cutoff_d_fdr = 2 unless(defined($cutoff_d_fdr));
$cutoff_c_fdr = 2 unless(defined($cutoff_c_fdr));
$multiple =10 unless(defined($multiple));
$mode = "RandomForest" unless(defined($mode));
$Rscript = "/data/Public_tools/R-4.0.2/bin/Rscript" unless(defined($Rscript));
$pvalues_in = "1e-20:1e-15:1e-14:1e-13:1e-12:1e-11:1e-10:1e-9:1e-8:1e-7:1e-6:1e-5:1e-4:5e-4:1e-3:5e-3:1e-2:5e-2:1e-1:5e-1:1" unless(defined($pvalues_in));
my @pvalues = split /:/, $pvalues_in;
$top_clone_n = 5000 unless(defined($top_clone_n));

#----- change to absolute path
my $current_path=$ENV{"PWD"};
$id_f_list = "$current_path/$id_f_list" unless($id_f_list=~/^\//);
$ic_f_list = "$current_path/$ic_f_list" unless($ic_f_list=~/^\//);
$out = "$current_path/$out" unless($out=~/^\//);


#   1. Identify Disease specific clones   -------------
open O, ">$out/Step1_identify_specific_clones.sh" or die;

print O "# 1. Identify Disease specific clones\n";
print O "perl $Bin/Get_clones_from_Disease_Control.pl $id_f_list $ic_f_list $out/Disease_control_clones_all.gz\n";
my $disease_num = `wc -l $id_f_list`;
$disease_num = (split /\s+/,$disease_num)[0];
my $control_num = `wc -l $ic_f_list`;
$control_num = (split /\s+/,$control_num)[0];
print O "perl $Bin/Re-cal_Clones_sample_support.pl $out/Disease_control_clones_all.gz $disease_num $control_num $out/Disease_control_clones_all.recal.gz\n";
print O "$Rscript $Bin/Fisher_exact_test.R $out/Disease_control_clones_all.recal.gz $out/Disease_control_clones_all.recal.pvalues.gz\n";
print O "$Rscript $Bin/FDR_correct_RR.R $out/Disease_control_clones_all.recal.pvalues.gz $cutoff_d_fdr $cutoff_c_fdr $out/Disease_control_clones_all.recal.pvalues.fdr.gz\n";
close O;

#   2. classification for all samples (All used for training and testings
open O, ">$out/Step3_calculate_memburden_allsamples.sh" or die;
system "mkdir -p $out/All" unless(-d "$out/All");
print O "#2. calculating memory burden for all samples\n";
for(@pvalues)
{
	print O "perl $Bin/Get_extended_clones.V3.pl $out/Disease_control_clones_all.recal.pvalues.fdr.gz $id_f_list $_ $cutoff_d_fdr $cutoff_c_fdr 1 > $out/All/Disease.specific.extended.clones.$_\n";
	print O "perl $Bin/Filter_clusters.pl $out/All/Disease.specific.extended.clones.$_ $out/Disease_control_clones_all.gz 100 10 $out/All/Disease.specific.extended.clones.$_.filter >$out/All/Disease.specific.extended.clones.$_.stat\n";
	print O "perl $Bin/Cal_memory_burden.All.V4.pl $out/All/Disease.specific.extended.clones.$_.filter $out/Disease_control_clones_all.recal.pvalues.gz $id_f_list $ic_f_list $_ $out/All $top_clone_n\n";
	print O "$Rscript $Bin/Select_final_clusters.V3.R $out/All/Clone_content.allsample.$_ $out/All/Disease.specific.extended.clones.$_.retain\n";
       	print O "perl $Bin/Get_final_clusters.pl $out/All/Disease.specific.extended.clones.$_.retain $out/All/Disease.specific.extended.clones.$_.filter>$out/All/Disease.specific.extended.clones.$_.filter.final\n";
	print O "perl $Bin/Cal_memory_burden.All.V4.pl $out/All/Disease.specific.extended.clones.$_.filter.final $out/Disease_control_clones_all.recal.pvalues.gz $id_f_list $ic_f_list $_ $out/All $top_clone_n\n";
}
#print O "perl $Bin/Cal_memory_burden.All.pl $out/Disease_control_clones_all.recal.pvalues.fdr.gz $id_f_list $ic_f_list $pvalues_in $out/All\n";
#if($mode eq "RandomForest"){
#	print O "$Rscript $Bin/RandomForest_AUC.R  $out/All/Clone_content.allsample.$pvalues[0] $out/All/Clone_content.allsample.$pvalues[0] $pvalues[0] All $out/All/Clone_content.allsample.$pvalues[0].pre|grep -v NULL >$out/All/AUC.All.stat\n";
#}else{
#	print O "$Rscript $Bin/Logistic.AUC.R  $out/All/Clone_content.allsample.$pvalues[0] $out/All/Clone_content.allsample.$pvalues[0] $pvalues[0] All $out/All/Clone_content.allsample.$pvalues[0].pre|grep -v NULL >$out/All/AUC.All.stat\n";
#}
#print O "perl $Bin/Cal_cross_entropy_loss.pl $out/All/Clone_content.allsample.$pvalues[0].pre $pvalues[0] All >$out/All/Loss.All.stat\n";

#my @N = @pvalues;
#shift @N;
#for(@N){
#	if($mode eq "RandomForest"){
#		print O "$Rscript $Bin/RandomForest_AUC.R $out/All/Clone_content.allsample.$_ $out/All/Clone_content.allsample.$_ $_ All $out/All/Clone_content.allsample.$_.pre|grep -v NULL >>$out/All/AUC.All.stat\n";
#	}else{
#		print O "$Rscript $Bin/Logistic.AUC.R $out/All/Clone_content.allsample.$_ $out/All/Clone_content.allsample.$_ $_ All $out/All/Clone_content.allsample.$_.pre|grep -v NULL >>$out/All/AUC.All.stat\n";
#	}
#	print O "perl $Bin/Cal_cross_entropy_loss.pl $out/All/Clone_content.allsample.$_.pre $_ All >>$out/All/Loss.All.stat\n";
#}
close O;

#   3. cross validtion with leave-one-out method
#open O, ">$out/Step2_crossvalidation_tot.sh" or die;

system "mkdir -p $out/Crossvalidation" unless(-d "$out/Crossvalidation");
system "mkdir -p $out/Crossvalidation_shell" unless(-d "$out/Crossvalidation_shell");
my $judge_sh = `find $out/Crossvalidation_shell -name "step1.*.sh"`;
if($judge_sh){
	`rm $out/Crossvalidation_shell/step1.*.sh`;
}
open O, ">$out/Crossvalidation_shell/Total_crossvalidation.sh" or die;
#open O1, ">$out/Crossvalidation_shell/step1.sh" or die;
#print O "#3. cross validtion with leave-one-out method\n";
#print O1 "#3. cross validtion with leave-one-out method\n";
#print O "#\nf=\$(ls $out/Crossvalidation/CV.logistics 2> /dev/null | wc -l)\nif [ \"\$f\" != \"0\" ]\nthen rm $out/Crossvalidation/CV.logistics\nfi\n";
#my $cv_mode;
#if($mode eq "RandomForest"){
#	`perl $Bin/Create_RandomForest_CV_R.pl $pvalues_in $out/RandomForest_CV.R`;
#	$cv_mode = "$out/RandomForest_CV.R";
#}else{
#	`perl $Bin/Create_Logistics_CV_R.pl $pvalues_in $out/Logistics_CV.R`;
#	$cv_mode = "$out/Logistics_CV.R";
#}
#print O1 "#\nf=\$(ls $out/Crossvalidation/CV.logistics 2> /dev/null | wc -l)\nif [ \"\$f\" != \"0\" ]\nthen rm $out/Crossvalidation/CV.logistics\nfi\n";
#print O1 "perl $Bin/Create_Logistics_CV_R.pl $pvalues_in $out/Logistics_CV.R\n";

my $disease_num_1 = $disease_num - 1;
my $control_num_1 = $control_num - 1; 

my @shell;


open I, "$id_f_list" or die;
while(<I>)
{
	chomp;
	my ($cdr3_f, $name) = split;
	my $com_sh = "perl $Bin/Modify_total_clones.pl $cdr3_f $name 1 $out/Disease_control_clones_all.gz $out/Disease_control_clones_all.recal.pvalues.gz $out/Crossvalidation/$name.gz $out/Crossvalidation/$name.same.pvalue\nperl $Bin/Re-cal_Clones_sample_support.pl $out/Crossvalidation/$name.gz $disease_num_1 $control_num $out/Crossvalidation/$name.recal.gz\n$Rscript $Bin/Fisher_exact_test.CV.R $out/Crossvalidation/$name.recal.gz $out/Crossvalidation/$name.recal.pvalue\ncat $out/Crossvalidation/$name.recal.pvalue $out/Crossvalidation/$name.same.pvalue >$out/Crossvalidation/$name.pvalues.all;gzip -f $out/Crossvalidation/$name.pvalues.all\n";
	#$com_sh .= "rm $out/Crossvalidation/$name.pre\n";
	$com_sh .= "perl $Bin/Get_extended_clones.CV.V3-3.pl $out/Crossvalidation/$name.pvalues.all.gz $pvalues_in  $cutoff_d_fdr $cutoff_c_fdr 1 > $out/Crossvalidation/$name.extended.clones\n";
	$com_sh .= "perl $Bin/Filter_clusters.CV.pl $out/Crossvalidation/$name.extended.clones $out/Disease_control_clones_all.gz 100 10 $out/Crossvalidation/$name.extended.clones.filter\n";
	$com_sh .= "perl $Bin/Cal_memory_burden.CV.V5-1.pl $out/Crossvalidation/$name.extended.clones.filter $out/Crossvalidation/$name.pvalues.all.gz $id_f_list $ic_f_list $out/Crossvalidation $top_clone_n $name\n";
	$com_sh .=  "$Rscript $Bin/Select_final_clusters.V3.R $out/Crossvalidation/$name.memory.burden.training  $out/Crossvalidation/$name.extended.clones.retain\n";
	$com_sh .=  "perl $Bin/Get_final_clusters.pl $out/Crossvalidation/$name.extended.clones.retain $out/Crossvalidation/$name.extended.clones.filter >$out/Crossvalidation/$name.extended.clones.filter.final\n";
	$com_sh .= "perl $Bin/Cal_memory_burden.CV.V5-2.pl $out/Crossvalidation/$name.extended.clones.filter.final $out/Crossvalidation/$name.pvalues.all.gz $id_f_list $ic_f_list $pvalues_in $out/Crossvalidation $top_clone_n $name\n";
	$com_sh .= "perl $Bin/Create_RandomForest.CV.V3.pl $pvalues_in $out/Crossvalidation/$name.RandomForest.R $out/Crossvalidation/$name.extended.clones.filter.final\n";
	 $com_sh .= "$Rscript $out/Crossvalidation/$name.RandomForest.R $out/Crossvalidation/$name.memory.burden.training $out/Crossvalidation/$name.memory.burden.testing |grep -v NULL > $out/Crossvalidation/$name.pre\n";
	$com_sh .= "rm $out/Crossvalidation/$name.same.pvalue $out/Crossvalidation/$name.gz $out/Crossvalidation/$name.recal.gz $out/Crossvalidation/$name.recal.pvalue\n";
	push @shell, $com_sh;
	print O "$com_sh";
}
close I;

open I, "$ic_f_list" or die;
while(<I>)
{
	chomp;
        my ($cdr3_f, $name) = split;
	my $com_sh = "perl $Bin/Modify_total_clones.pl $cdr3_f $name 0 $out/Disease_control_clones_all.gz $out/Disease_control_clones_all.recal.pvalues.gz $out/Crossvalidation/$name.gz $out/Crossvalidation/$name.same.pvalue\nperl $Bin/Re-cal_Clones_sample_support.pl $out/Crossvalidation/$name.gz $disease_num $control_num_1 $out/Crossvalidation/$name.recal.gz\n$Rscript $Bin/Fisher_exact_test.CV.R $out/Crossvalidation/$name.recal.gz $out/Crossvalidation/$name.recal.pvalue\ncat $out/Crossvalidation/$name.recal.pvalue $out/Crossvalidation/$name.same.pvalue >$out/Crossvalidation/$name.pvalues.all;gzip -f $out/Crossvalidation/$name.pvalues.all\n";
	#$com_sh .= "rm $out/Crossvalidation/$name.pre\n";
	$com_sh .= "perl $Bin/Get_extended_clones.CV.V3-3.pl $out/Crossvalidation/$name.pvalues.all.gz $pvalues_in  $cutoff_d_fdr $cutoff_c_fdr 1 > $out/Crossvalidation/$name.extended.clones\n";
        $com_sh .= "perl $Bin/Filter_clusters.CV.pl $out/Crossvalidation/$name.extended.clones $out/Disease_control_clones_all.gz 100 10 $out/Crossvalidation/$name.extended.clones.filter\n";
        $com_sh .= "perl $Bin/Cal_memory_burden.CV.V5-1.pl $out/Crossvalidation/$name.extended.clones.filter $out/Crossvalidation/$name.pvalues.all.gz $id_f_list $ic_f_list $out/Crossvalidation $top_clone_n $name\n";
	$com_sh .=  "$Rscript $Bin/Select_final_clusters.V3.R $out/Crossvalidation/$name.memory.burden.training  $out/Crossvalidation/$name.extended.clones.retain\n";
        $com_sh .=  "perl $Bin/Get_final_clusters.pl $out/Crossvalidation/$name.extended.clones.retain $out/Crossvalidation/$name.extended.clones.filter >$out/Crossvalidation/$name.extended.clones.filter.final\n";        
	$com_sh .= "perl $Bin/Cal_memory_burden.CV.V5-2.pl $out/Crossvalidation/$name.extended.clones.filter.final $out/Crossvalidation/$name.pvalues.all.gz $id_f_list $ic_f_list $pvalues_in $out/Crossvalidation $top_clone_n $name\n";
        $com_sh .= "perl $Bin/Create_RandomForest.CV.V3.pl $pvalues_in $out/Crossvalidation/$name.RandomForest.R $out/Crossvalidation/$name.extended.clones.filter.final\n";
         $com_sh .= "$Rscript $out/Crossvalidation/$name.RandomForest.R $out/Crossvalidation/$name.memory.burden.training $out/Crossvalidation/$name.memory.burden.testing |grep -v NULL > $out/Crossvalidation/$name.pre\n";

	$com_sh .= "rm $out/Crossvalidation/$name.same.pvalue $out/Crossvalidation/$name.gz $out/Crossvalidation/$name.recal.gz $out/Crossvalidation/$name.recal.pvalue\n";
	push @shell, $com_sh;
	print O "$com_sh";
}
close I;

my $flag_num = 0;
for(my $i=0;$i<=$#shell;$i++)
{
	if($i==0){
		open C, ">$out/Crossvalidation_shell/step1.$flag_num.sh" or die;
	}
	elsif($i!=0 && ($i+1) % $multiple == 0){
		close C;
		$flag_num++;
		open C, ">$out/Crossvalidation_shell/step1.$flag_num.sh" or die;
	}
	print C "$shell[$i]";
}
close C if(($#shell+1) % $multiple != 0);

#     3.4
open O4, ">$out/Crossvalidation_shell/step2.sh" or die;
print O "cat $out/Crossvalidation/*.pre >$out/Crossvalidation/CV.logistics\n";
print O4 "cat $out/Crossvalidation/*.pre >$out/Crossvalidation/CV.logistics\n";
print O "perl $Bin/Cal_cross_entropy_loss.CV.pl $out/Crossvalidation/CV.logistics CV $pvalues_in >$out/Crossvalidation/Loss.CV.stat\n";
print O4 "perl $Bin/Cal_cross_entropy_loss.CV.pl $out/Crossvalidation/CV.logistics CV $pvalues_in >$out/Crossvalidation/Loss.CV.stat\n";
print O "$Rscript $Bin/Cal_AUC.CV.R $out/Crossvalidation/CV.logistics $pvalues_in |grep -v NULL >$out/Crossvalidation/AUC.CV.stat\n";
print O4 "$Rscript $Bin/Cal_AUC.CV.R $out/Crossvalidation/CV.logistics $pvalues_in |grep -v NULL >$out/Crossvalidation/AUC.CV.stat\n";
close O;
close O4;

#       4. statistics and figures
open O, ">$out/Step4.figure.sh" or die;
print O "perl $Bin/Get_partial_data_for_fdr.pl $out/Disease_control_clones_all.recal.pvalues.fdr.gz $pvalues_in $out/clones_num_by.pavlues>$out/pvalue.fdr.for.plot\n";
print O "echo \"pvalue	AUC	AUC-1	AUC-2	flag	accuracy\" >$out/Both.all.cv.AUC;cat $out/Crossvalidation/AUC.CV.stat >>$out/Both.all.cv.AUC\n";
print O "echo \"pvalue	loss	flag\" >$out/Both.all.cv.loss;cat $out/Crossvalidation/Loss.CV.stat >>$out/Both.all.cv.loss\n";
print O "$Rscript $Bin/FDR_Pvalue.R $out/pvalue.fdr.for.plot $out/pvalue.fdr.for.plot.pdf\n";
print O "$Rscript $Bin/AUC.Loss.R $out/Both.all.cv.AUC $out/Both.all.cv.loss $out/AUC.Loss.pdf\n";
print O "$Rscript $Bin/Num_Pvaule.R $out/clones_num_by.pavlues $out/clones_num_by.pavlues.pdf\n";

