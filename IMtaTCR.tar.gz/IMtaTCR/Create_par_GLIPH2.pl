#!/usr/bin/perl -w
use strict;

die "perl $0 <input.list><gliph2><outdir>\n" unless(@ARGV==3);
my $gliph2 = $ARGV[1];
my $outdir = $ARGV[2];
open I, "$ARGV[0]" or die;
while(<I>)
{
	chomp;
	my @L=split /\//,$_;
	$L[-1]=~s/\.gliph2\.input//;
	my $name = $L[-1];
	open O, ">$outdir/$L[-1].par" or die;
	print O "out_prefix=$name\ncdr3_file=$_\nrefer_file=$gliph2/human_v2.0/ref_CD48_v2.0.txt\nhla_file =$gliph2/hla.txt\nv_usage_freq_file=$gliph2/human_v2.0/ref_V_CD48_v2.0.txt\ncdr3_length_freq_file=$gliph2/human_v2.0/ref_L_CD48_v2.0.txt\nlocal_min_pvalue=0.001\np_depth = 1000\nglobal_convergence_cutoff = 1\nsimulation_depth=1000\nkmer_min_depth=3\nlocal_min_OVE=10\nalgorithm=GLIPH2\nall_aa_interchangeable=1\n";
	close O;
}
close I;
