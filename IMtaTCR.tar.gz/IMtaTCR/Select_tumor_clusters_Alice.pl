#!/usr/bin/perl -w
use strict;

die "perl $0 <in><ratio><readcount_intumor>\n" unless(@ARGV==3);
my $ratio = $ARGV[1];
my $readcount_tumor = $ARGV[2];
open I, "$ARGV[0]" or die;
<I>;
while(<I>)
{
	chomp;
	my @line = split;
	last if($line[3] eq "-" || $line[6] eq "-");
	my ($t_n,$t_f) = ($line[4],$line[5]);
	my ($n_n,$n_f) = ($line[7],$line[8]);
	if($t_n == 1 && $n_n ==1 && $t_f > $ratio*$n_f && $t_f>= $readcount_tumor){
		print "$line[0]\t$line[3]\n";
	}elsif($t_n ==1 && $n_n == 0 && $t_f>= $readcount_tumor){
		print "$line[0]\t$line[3]\n";	
	}
}
close I;
