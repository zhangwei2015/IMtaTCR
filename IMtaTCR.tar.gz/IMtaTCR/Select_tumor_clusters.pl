#!/usr/bin/perl -w
use strict;

die "perl $0 <in><DEGseq><tumor_readcount><fold_change><pvalue>\n" unless(@ARGV==5);

my $cluster_m = $ARGV[2];
my $fold = $ARGV[3];
my $pvalue = $ARGV[4];

open I, "$ARGV[0]" or die;
<I>;

my %cluster_tum_num;
while(<I>)
{
	chomp;
	my @line = split;
	last if($line[3] eq "-" || $line[6] eq "-");
	#my ($t_n,$t_f) = split /:/,$line[4];
	#my ($n_n,$n_f) = split /:/,$line[6];
	#if($t_n >=2 && $t_n >$n_n && $t_f >$n_f){
	#	print "$line[0]\t$line[3]\n";	
	#}
	$cluster_tum_num{$line[0]} = [($line[3],$line[5])];
}
close I;

open I, "$ARGV[1]" or die;
<I>;
while(<I>)
{
	chomp;
	my @line = split;
	next if($line[4] eq "NA" || $line[7] eq "NA");
	if(exists $cluster_tum_num{$line[0]} && $cluster_tum_num{$line[0]}->[1] >=$cluster_m && $line[4] >=$fold && $line[7] <$pvalue ){
		print "$line[0]\t$cluster_tum_num{$line[0]}->[0]\n";
	}
}
close I;
