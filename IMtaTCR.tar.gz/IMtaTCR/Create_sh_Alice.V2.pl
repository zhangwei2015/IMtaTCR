#!/user/bin/perl -w
use strict;

die "perl $0 <patient.sample.infor><tumor.dir><normal.dir><out.dir><norm.num><tumor/normal><readcount_tumor><Bin>\n" unless(@ARGV==8);

my $outdir = $ARGV[3];
my $norm_num = $ARGV[4];
my $ratio = $ARGV[5];
my $readcount_tumor = $ARGV[6];
my $Bin = $ARGV[7];

open I, "$ARGV[0]" or die;
<I>;
while(<I>)
{
	chomp;
	my @line = split;
	my $ind = "S$line[0]";
	my $tumor;# = "/data/users/zhangwei/Lung_cancer/SCLC/PMID_34789716/Clonotypes/$line[1]/$line[1]_CDR3_AA_Vfamily_Jgene.gz";
	my $normal = "$ARGV[2]/$line[1].alice.input";
	$normal = "NA" if($line[1] eq "-");
	my $blood = "NA";

	for(my $i=2;$i<=$#line;$i++){
		$tumor = "$ARGV[1]/$line[$i].alice.input";
		$tumor = "NA" if($line[$i] eq "-");
		print "perl $Bin/Split_into_pos_Alice.V2.pl $outdir/${ind}.alice $tumor $normal $blood $norm_num > $outdir/$ind.$i.split\n";
		print "perl $Bin/Select_tumor_clusters_Alice.pl $outdir/$ind.$i.split $ratio $readcount_tumor > $outdir/$ind.$i.selected\n";
		print "perl -ne \'chomp;my \@L=split;my \@N=split /_/,\$L[1];\$N[2] = (split /-/,\$N[2])[0];print \"\$L[0]\\t\$N[1]_\$N[2]_\$N[3]\\n\";\' $outdir/$ind.$i.selected >$outdir/$ind.$i.selected.final\n";
	}

	#my $blood = "/data/users/zhangwei/Stomach_cancer/Final/Blood_Tumor/$line[3]/$line[3]_CDR3_AA.frequency.clones.gz";
	#my $blood = "NA";
	#$tumor = "NA" if($line[1] eq "-");
	#$normal = "NA" if($line[1] eq "-");
	#$blood = "NA" if($line[3] eq "-");

	#print "perl Split_into_pos_Gliph2_CDR3VfJ.pl ${ind}_cluster.txt $tumor $normal $blood > $ind.split\n";
	#print "perl Select_tumor_clusters_Gliph2.pl $ind.split > $ind.selected\n";
}
close I;
