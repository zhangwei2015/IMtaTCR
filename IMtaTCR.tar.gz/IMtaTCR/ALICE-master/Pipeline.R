args <- commandArgs(TRUE)
input<-args[1]
outdir<-args[2]
output<-args[3]

library(data.table)
read_in<-fread(input)
#S1d0<-fread("sample/S1_d0_V9_J2_7.tsv")
#S1<-list(d0=S1d0,d15=S1d15)
S<-list(d=read_in)
source("/data/users/zhangwei/TCR_cluster/ALICE-master/ALICE.R")
S_alice<-ALICE_pipeline(DTlist=S,folder=outdir,cores=1,iter=10,nrec=5e5) #this takes few minutes to run
#sapply(S1_alice,nrow)
write.table(as.data.frame(S_alice),file=output,quote=F,sep="\t")
