library(DEGseq)
args <- commandArgs(TRUE)
infile1<-args[1]
infile2<-args[2]

#geneExpFile <- system.file("extdata", "GeneExpExample5000.txt", package="DEGseq")
geneExpMatrix1 <- readGeneExp(file=infile1, geneCol=1, valCol=6)
geneExpMatrix2 <- readGeneExp(file=infile1, geneCol=1, valCol=9)
#write.table(geneExpMatrix1,row.names=FALSE)
#write.table(geneExpMatrix2[30:31,],row.names=FALSE)
#outputDir <- file.path("/data/users/zhangwei/Lung_cancer/SCLC/PMID_34789716/GLIPH2/T")
outputDir<-infile2
DEGexp(geneExpMatrix1=geneExpMatrix1, groupLabel1="freq1",geneExpMatrix2=geneExpMatrix2, groupLabel2="freq2",outputDir=outputDir, method="MARS")
