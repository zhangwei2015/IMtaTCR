#!/usr/bin/perl -w
use strict;

die "perl $0 <>\n" unless(@ARGV==1);

my $cutoff = 100;
open I, "$ARGV[0]" or die;
while(<I>)
{
	chomp;
	my @line = split;
	my %all;# = split /[:,]/,$line[1];
	my @N = split /:/,$line[1];
	for my $t (@N){
		my ($t1, $t2) = split /,/,$t;
		my ($s,$v,$j) = split /_/,$t1;
		$v = (split /-/,$v)[0];
		$t1 = join "_", ($s,$v,$j);
		$all{$t1} += $t2;
	}

	my %backup;
	my $new;
	while(1)
	{
		last if(scalar(keys %all) == scalar(keys %backup));
		my $max;
		for my $c(sort {$all{$b}<=>$all{$a}} keys %all)
		{
			next if(exists $backup{$c});
			if(defined($max)){
				my $flag = &Compare($max,$c,$all{$c});
				$backup{$c} = $all{$c} if($flag==1);
			}else{
				$max = "$c\t$all{$c}";
				if(defined($new)){
					$new .= ":$c,$all{$c}";
				}else{
					$new = "$c,$all{$c}";
				}
				$backup{$c} = $all{$c};
			}
			
		}
	}
	print "$line[0]\t$new\n";
}
close I;


sub Compare
{
	my ($max,$clone,$num) = @_;
	my ($max_c,$max_n) = split /\t/,$max;
	my ($max_c_c,$max_c_v,$max_c_j) = split /_/,$max_c;
	my ($clone_c,$clone_v,$clone_j) = split /_/,$clone;
	if($max_n/$num < $cutoff or length($max_c_c) != length($clone_c)){
		return 0;
	}
	if($max_c_v ne $clone_v or $max_c_j ne $clone_j){
		return 0;
	}
	
	my @max_N = split //,$max_c_c;
	my @clone_N = split //,$clone_c;
	my $mismatch = 0;
	for(my $i=0; $i<=$#max_N ; $i++){
		last if($mismatch >1);
		$mismatch++ if($max_N[$i] ne $clone_N[$i]);
	}
	if($mismatch <=1){
		return 1;
	}else{
		return 0;
	}

}
