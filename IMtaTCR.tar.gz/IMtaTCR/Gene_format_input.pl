#!/usr/bin/perl -w
use strict;
use File::Basename;

die "perl $0 <in><outdir>\n" unless(@ARGV==2);
my ($input_f,$Outdir) = @ARGV;
#my $name = basename($in_f);
#$name =~ s/\.structure\.final\.gz$//;
#$name =~ s/_CDR3_VJgene\.gz$//;

my %new_inf;
print "individual\tnormal\ttumor\n";
open F, "$input_f" or die;
<F>;
while(<F>)
{
	chomp;
	my @L = split;
	push @{$new_inf{$L[0]}{$L[2]}}, $L[1];

	my $name = $L[1];
	my $outdir = "$Outdir/$L[2]";
	my $in_f = $L[3];
open I, "gzip -dc $in_f|" or die;
#<I>;
my %Clone;
my %Gliph2;
my %iSMART;
my %Allele;
my $tot_n = 0;
while(<I>)
{
	chomp;
	my @F = split;
        # filtration
	#next if($F[2] =~ /_unF/ or $F[4] =~ /_unF/);
	#next if($F[1] =~ /out-of-frame/);
	#next if(length($F[8])<3);
	#next unless($F[8] =~ /^C/ && $F[8] =~ /F$/);

	#next if($F[2] eq "NA" || $F[4] eq "NA");# some CDR3 found by conserve rgion, without V or J
	
	#$tot_n++;
        # V/J v-J usage
	#my $vgene = (split /\*/,$F[2])[0];
	#my $jgene = (split /\*/,$F[4])[0];
	#$vgene = (split /-/,$vgene)[0];
	my ($cdr3_nt,$cdr3_aa,$vgene,$jgene) = split /_/,$F[0];
	$tot_n+=$F[1];
	my $com = "$cdr3_nt\t$cdr3_aa\t$vgene\t$jgene";
	$Clone{$com}+=$F[1];	
	$Gliph2{"$cdr3_aa\t$vgene\t$jgene"}+=$F[1];
	$iSMART{"$cdr3_aa\t$vgene\t$jgene"}+=$F[1];
	#$Allele{"$F[8]\t$F[2]\t$F[4]"}++;
}
close I;

open O, ">$outdir/$name.gliph2.input" or die;
print O "#CDR3b\tTRBV\tTRBJ\tCDR3a\tsubject:condition\tcount\n";
for(sort {$Gliph2{$b}<=>$Gliph2{$a}} keys %Gliph2)
{
	print O "$_\tNA\tNA\t$Gliph2{$_}\n";
}
close O;

open O, ">$outdir/$name.alice.input" or die;
my $flag = 0;
print O "Rank\tRead.count\tRead.proportion\tCDR3.nucleotide.sequence\tCDR3.amino.acid.sequence\tbestVGene\tbestJGene\n";
for(sort {$Clone{$b}<=>$Clone{$a}} keys %Clone)
{
	$flag++;
	my $rate = $Clone{$_}/$tot_n*100;
	print O "$flag\t$Clone{$_}\t$rate\t$_\n";
}
close O;
open O, ">$outdir/$name.iSMART.input" or die;
print O "aminoAcid\tvMaxResolved\tfrequencyCount\tjMaxResolved\n";
for(sort {$iSMART{$b}<=>$iSMART{$a}} keys %iSMART )
{
	my $rate = $iSMART{$_}/$tot_n*100;
	my @N = split /\t/,$_;

	print O "$N[0]\t$N[1]\t$rate\t$N[2]\n";
}
close O;

}
#open O, ">$outdir/$name.CDR3VJ" or die;
#for(sort {$Allele{$b}<=>$Allele{$a}} keys %Allele )
#{
#        my $rate = $Allele{$_}/$tot_n*100;
#        print O "$_\t$rate\n";
#}
#close O;

for my $ind (keys %new_inf)
{
	print "$ind";
	for my $f("Normal","Tumor"){
		$new_inf{$ind}{$f}->[0] = "-" if(!defined $new_inf{$ind}{$f}->[0]);
		for(@{$new_inf{$ind}{$f}}){
			print "\t$_";
		}
	}
	print "\n";
}

